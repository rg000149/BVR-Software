
package contactinfosystem;

import java.awt.Color;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ContactNumber extends javax.swing.JFrame {
    Connection con;
    ResultSet rs;
    PreparedStatement pt;
    Statement st;   
    static int count=0;
    String U="yes";
    
    public ContactNumber() {
        initComponents();
        setconnection();
    }
    public void setconnection(){
        try
            {
                Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/contacts", "root", "");
            st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                System.out.println("Connected");
            }
            catch(Exception e)
            {
                System.out.println("Error in Connection plz Check :" +e);
            }
    }
  
 
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        msgbox = new javax.swing.JOptionPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        lblLogOut = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        lblAdminName = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtNum = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        comboCount = new javax.swing.JComboBox();
        txtStat = new javax.swing.JTextField();
        btnNext = new javax.swing.JButton();
        btnsave = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        btnCancel = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(716, 499));
        setMinimumSize(new java.awt.Dimension(716, 499));
        setResizable(false);
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(204, 251, 218));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 255)));
        jPanel1.setMaximumSize(new java.awt.Dimension(700, 478));
        jPanel1.setMinimumSize(new java.awt.Dimension(700, 478));
        jPanel1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jPanel1MouseMoved(evt);
            }
        });
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(0, 102, 102));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(0));

        lblLogOut.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblLogOut.setForeground(new java.awt.Color(255, 255, 255));
        lblLogOut.setText("Log Out");
        lblLogOut.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblLogOutMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblLogOutMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblLogOutMouseExited(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Hello");

        lblAdminName.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblAdminName.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblAdminName, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 448, Short.MAX_VALUE)
                .addComponent(lblLogOut)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblLogOut)
                        .addComponent(jLabel2))
                    .addComponent(lblAdminName, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(1, 1, 708, 43);

        jPanel3.setBackground(new java.awt.Color(204, 251, 218));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setText("Name");

        jLabel3.setText("Mob / LLN");

        txtNum.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtNumKeyReleased(evt);
            }
        });

        jLabel4.setText("State");

        jLabel5.setText("Country");

        comboCount.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select", "India", "Saudi Arebia", "America", "Pakistan", "Shri Lanka", "Dubai", "England", "Africa" }));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtStat)
                    .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jLabel5))
                .addGap(23, 23, 23)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtNum, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboCount, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(txtNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel4)
                        .addComponent(txtStat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel5))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(comboCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(72, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3);
        jPanel3.setBounds(92, 111, 522, 225);

        btnNext.setText(" Next ");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });
        jPanel1.add(btnNext);
        btnNext.setBounds(364, 386, 61, 23);

        btnsave.setText(" Save ");
        btnsave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsaveActionPerformed(evt);
            }
        });
        jPanel1.add(btnsave);
        btnsave.setBounds(451, 386, 63, 23);

        btnBack.setText(" Back ");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        jPanel1.add(btnBack);
        btnBack.setBounds(184, 386, 61, 23);

        jLabel6.setText("(  If you have another number then press next button otherwise save information by pressing save button  )");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(60, 350, 630, 28);

        btnCancel.setText("Cancel");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });
        jPanel1.add(btnCancel);
        btnCancel.setBounds(273, 386, 70, 23);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 710, 470);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void lblLogOutMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLogOutMouseEntered
       lblLogOut.setForeground(Color.red);
    }//GEN-LAST:event_lblLogOutMouseEntered

    private void lblLogOutMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLogOutMouseExited
        lblLogOut.setForeground(Color.white);
    }//GEN-LAST:event_lblLogOutMouseExited

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        new Menu().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    private void lblLogOutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLogOutMouseClicked
        new LogIn().setVisible(true);
        this.dispose(); 
    }//GEN-LAST:event_lblLogOutMouseClicked

    private void btnsaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsaveActionPerformed
        if(txtNum.getText().equals("")){
                 msgbox.showMessageDialog(this, "Enter the property first ", "UnSave", 1, null);
                 txtName.setEditable(true);
                    txtNum.setText("");
                    txtStat.setEditable(true);
                    comboCount.setEditable(true);
        }
        else{
            
            String name,num,stat,cont;
            name=txtName.getText();
            num=txtNum.getText();
            stat=txtStat.getText();
            cont=(String)comboCount.getSelectedItem();
            if(cont.equals("Select"))
                msgbox.showMessageDialog(this, "Choose an authenticated country", "Authenticated Country", 3, null);
            else{
                try{
                    pt=con.prepareStatement("insert into ContactDetail values(?,?,?,?)");
                    pt.setString(1, num);
                    pt.setString(2,name);
                    pt.setString(3,stat);
                    pt.setString(4,cont);
                    pt.executeUpdate();
                    pt=con.prepareStatement("insert into History values(?,?,?,?,?)");
                    pt.setString(1, num);
                    pt.setString(2,name);
                    pt.setString(3,stat);
                    pt.setString(4,cont);
                    pt.setString(5,"New Entry");
                    pt.executeUpdate();
                    msgbox.showMessageDialog(this, "Contact saved  successfully", "Save", 1, null);
                    clear();
                    txtName.setEditable(true);
                    txtStat.setEditable(true);
                    comboCount.setEditable(true);
                    count=0;
            
                }catch (Exception ex){
                   ex.printStackTrace();
                    msgbox.showMessageDialog(this, "This number is already exist", "Unsave", 2, null);
                }
            }
        }
    }//GEN-LAST:event_btnsaveActionPerformed
    public void clear()
    {
        txtName.setText("");
        txtNum.setText("");
        txtStat.setText("");
        comboCount.setSelectedIndex(0);
            
    }
    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:
        String name,num,stat,cont;
        name=txtName.getText();
        num=txtNum.getText();
        stat=txtStat.getText();
        cont=(String)comboCount.getSelectedItem();
        try{
            pt=con.prepareStatement("insert into ContactDetail values(?,?,?,?)");
                   pt.setString(1, num);
                   pt.setString(2,name);
                   pt.setString(3,stat);
                   pt.setString(4,cont);
                   pt.executeUpdate();
            pt=con.prepareStatement("insert into History values(?,?,?,?,?)");
                    pt.setString(1, num);
                    pt.setString(2,name);
                    pt.setString(3,stat);
                    pt.setString(4,cont);
                    pt.setString(5,"New Entry");
                    pt.executeUpdate();
            msgbox.showMessageDialog(this, "Contact saved  successfully", "Save", 1, null);
            txtName.setEditable(false);
            txtStat.setEditable(false);
            comboCount.setEnabled(false);
            txtNum.setText("");
            count=0;
            
        }catch (Exception ex){
            ex.printStackTrace();
            msgbox.showMessageDialog(this, "Process failed", "Unsave", 2, null);
            }
    }//GEN-LAST:event_btnNextActionPerformed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        count=0;
        clear();
        txtName.setEditable(true);
        txtStat.setEditable(true);
        comboCount.setEnabled(true);
    }//GEN-LAST:event_btnCancelActionPerformed

    private void jPanel1MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MouseMoved
        // TODO add your handling code here:
         try{
            rs=st.executeQuery("select * from LogIn where Status='"+U+"'");
            rs.next();
            lblAdminName.setText(rs.getString(1));
        }catch(Exception ex){}
    }//GEN-LAST:event_jPanel1MouseMoved

    private void txtNumKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumKeyReleased
        try{
        int temp;
        String string="",num=txtNum.getText();
        int i,len;
        len=num.length();
        count=len-1;
    if(count<10){
        if(count==0)
        {
            try{
                temp=Integer.parseInt(num);
                count+=1;
            }catch(Exception ex){
                JOptionPane.showMessageDialog(this,"Enter only Integer value");
                txtNum.setText("");
             }
        }else {
            String substr=num.substring(count);
            try{
                temp=Integer.parseInt(substr);
                 count+=1;
            }catch(Exception ex){
                JOptionPane.showMessageDialog(this,"Enter only Integer value");
                txtNum.setText(num.substring(0,count));
             }
        }
    }else{
           txtNum.setText(num.substring(0,count));
       }    
     }catch(Exception ex){}  
    }//GEN-LAST:event_txtNumKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ContactNumber.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ContactNumber.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ContactNumber.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ContactNumber.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ContactNumber().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnsave;
    private javax.swing.JComboBox comboCount;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel lblAdminName;
    private javax.swing.JLabel lblLogOut;
    private javax.swing.JOptionPane msgbox;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtNum;
    private javax.swing.JTextField txtStat;
    // End of variables declaration//GEN-END:variables
}
