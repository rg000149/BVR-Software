package contactinfosystem;

import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Menu extends javax.swing.JFrame {
    Connection con;
    ResultSet rs;
    PreparedStatement pt;
    Statement st;
    String U="Yes";
    int flag=0;
    String [] cp=new String[]{"Number","Name","State","Country"};
    DefaultTableModel dtmp=new DefaultTableModel(cp,0){
        @Override
        public boolean isCellEditable(int row,int column)
        {
           
                    return false;
           
        }
    };
    
    public Menu() {
        initComponents();
        setconnection();
        Disable();
        btndel.setEnabled(false);
        btnupdt.setEnabled(false);       
    }
    public void setconnection()
    {
    
            try
            {
                Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/contacts", "root", "");
                st=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY); 
                System.out.println("Connected");
                rs=st.executeQuery("select * from ContactDetail");
                fillgrid(rs);
            }
            catch(Exception e)
            {
                System.out.println("Error in Connection plz Check :" +e);
            }
    }
       public void fillgrid(ResultSet rs1)
   {
           Contactgrid();
          Object []ob=new Object[5];
           try
           {        
               while(rs1.next())
               {
                   
                   ob[0]=rs1.getString(1);
                   ob[1]=rs1.getString(2);
                   ob[2]=rs1.getString(3);
                   ob[3]=rs1.getString(4);   
                   dtmp.addRow(ob);
                  congrid.setModel(dtmp);
               }    
           }
           catch(Exception e)
           {
               e.printStackTrace(); 
           }
  }
   public void Contactgrid()
  {
      int rc=dtmp.getRowCount();
        for(int i=0;i<rc;i++)
        {
            dtmp.removeRow(0);
        }
  }
    public void Disable()
    {
       txtNum.setVisible(false);
        txtName.setVisible(false);
        txtStat.setVisible(false);
        txtCount.setVisible(false);
        txtSearch.setVisible(false);
        comboSearch.setVisible(false);
        btnOK.setVisible(false); 
        
    }
   

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        congrid = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lblAdminName = new javax.swing.JLabel();
        lblLogout = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        btnSearch = new javax.swing.JButton();
        btnupdt = new javax.swing.JButton();
        btnNew = new javax.swing.JButton();
        btndel = new javax.swing.JButton();
        btnhis = new javax.swing.JButton();
        btnsetting = new javax.swing.JButton();
        txtNum = new javax.swing.JTextField();
        txtName = new javax.swing.JTextField();
        txtStat = new javax.swing.JTextField();
        txtCount = new javax.swing.JTextField();
        txtSearch = new javax.swing.JTextField();
        comboSearch = new javax.swing.JComboBox();
        btnOK = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(706, 499));
        setResizable(false);
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(204, 251, 218));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 255)));
        jPanel1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jPanel1MouseMoved(evt);
            }
        });
        jPanel1.setLayout(null);

        congrid.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        congrid.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Mob/ Land Line Number", "Name", "State", "Country"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        congrid.setGridColor(new java.awt.Color(255, 255, 255));
        congrid.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                congridMouseClicked(evt);
            }
        });
        congrid.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                congridMouseMoved(evt);
            }
        });
        jScrollPane1.setViewportView(congrid);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(11, 207, 678, 251);

        jPanel2.setBackground(new java.awt.Color(0, 102, 102));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Hello ");

        lblAdminName.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblAdminName.setForeground(new java.awt.Color(255, 255, 255));

        lblLogout.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblLogout.setForeground(new java.awt.Color(255, 255, 255));
        lblLogout.setText("Log Out");
        lblLogout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblLogoutMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblLogoutMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblLogoutMouseExited(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblAdminName, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 453, Short.MAX_VALUE)
                .addComponent(lblLogout)
                .addGap(12, 12, 12))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblAdminName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblLogout, javax.swing.GroupLayout.Alignment.LEADING))
                .addGap(34, 34, 34))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(1, 1, 698, 40);

        jPanel3.setBackground(new java.awt.Color(204, 251, 218));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btnSearch.setText("Search ");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        btnupdt.setText("Update");
        btnupdt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdtActionPerformed(evt);
            }
        });

        btnNew.setText("New");
        btnNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewActionPerformed(evt);
            }
        });

        btndel.setText("Delete");
        btndel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndelActionPerformed(evt);
            }
        });

        btnhis.setText("History");
        btnhis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhisActionPerformed(evt);
            }
        });

        btnsetting.setText("Setting");
        btnsetting.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsettingActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(btnSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(btnNew, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(btndel, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addComponent(btnupdt, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(btnhis, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(btnsetting, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(41, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSearch)
                    .addComponent(btnNew)
                    .addComponent(btndel)
                    .addComponent(btnupdt)
                    .addComponent(btnhis)
                    .addComponent(btnsetting))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3);
        jPanel3.setBounds(11, 50, 678, 43);
        jPanel1.add(txtNum);
        txtNum.setBounds(20, 160, 144, 30);
        jPanel1.add(txtName);
        txtName.setBounds(190, 160, 144, 30);
        jPanel1.add(txtStat);
        txtStat.setBounds(360, 160, 144, 30);
        jPanel1.add(txtCount);
        txtCount.setBounds(530, 160, 144, 30);

        txtSearch.setText("Search");
        txtSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtSearchMouseClicked(evt);
            }
        });
        txtSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtSearchKeyReleased(evt);
            }
        });
        jPanel1.add(txtSearch);
        txtSearch.setBounds(54, 99, 156, 30);

        comboSearch.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Search what", "Number", "Name", "State", "Country" }));
        jPanel1.add(comboSearch);
        comboSearch.setBounds(216, 99, 101, 30);

        btnOK.setText("OK");
        btnOK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOKActionPerformed(evt);
            }
        });
        jPanel1.add(btnOK);
        btnOK.setBounds(323, 99, 47, 30);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 700, 470);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jPanel1MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MouseMoved
        try{
            rs=st.executeQuery("select * from LogIn where Status='"+U+"'");
            rs.next();
            lblAdminName.setText(rs.getString(1));
        }catch(Exception ex){}
    }//GEN-LAST:event_jPanel1MouseMoved

    private void txtSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtSearchMouseClicked
        String combo=(String)comboSearch.getSelectedItem();
        if(combo.equals("Search what")==true)
            JOptionPane.showMessageDialog(this,"Please select search type ","Suggestion",3, null);
        else                
          txtSearch.setText("");
          txtNum.setVisible(false);
          txtName.setVisible(false);
          txtStat.setVisible(false);
          txtCount.setVisible(false);
          btndel.setEnabled(false);
          btnupdt.setEnabled(false);
    }//GEN-LAST:event_txtSearchMouseClicked

    private void btnsettingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsettingActionPerformed
        new Setting().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnsettingActionPerformed

    
    private void btnNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewActionPerformed
        new ContactNumber().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnNewActionPerformed

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        txtNum.setVisible(false);
        txtName.setVisible(false);
        txtStat.setVisible(false);
        txtCount.setVisible(false);
        txtSearch.setVisible(true);
        comboSearch.setVisible(true);
        btnOK.setVisible(true);
        try{
            rs=st.executeQuery("select * from ContactDetail");
            fillgrid(rs);                  
        }catch(Exception ex){}
    }//GEN-LAST:event_btnSearchActionPerformed

    private void lblLogoutMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLogoutMouseExited
        lblLogout.setForeground(Color.white);
    }//GEN-LAST:event_lblLogoutMouseExited

    private void lblLogoutMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLogoutMouseEntered
        lblLogout.setForeground(Color.red);
    }//GEN-LAST:event_lblLogoutMouseEntered

    private void lblLogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLogoutMouseClicked
        new LogIn().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_lblLogoutMouseClicked

    private void congridMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_congridMouseMoved
        try{
            rs=st.executeQuery("select * from LogIn where Status='"+U+"'");
            rs.next();
            lblAdminName.setText(rs.getString(1));
        }catch(Exception ex){}
    }//GEN-LAST:event_congridMouseMoved

    private void congridMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_congridMouseClicked
        int row=congrid.getSelectedRow();

        btndel.setEnabled(true);
        btnupdt.setEnabled(true);
        txtName.setVisible(true);
        txtNum.setVisible(true);
        txtStat.setVisible(true);
        txtCount.setVisible(true);
        String num=(String)congrid.getValueAt(row,0);     
        try{
            rs=st.executeQuery("select * from ContactDetail where Number='"+num+"'");
            rs.first();
            txtNum.setText(rs.getString(1));
            txtName.setText(rs.getString(2));
            txtStat.setText(rs.getString(3));
            txtCount.setText(rs.getString(4));
            pt.executeUpdate();

        }catch(Exception ex){}

    }//GEN-LAST:event_congridMouseClicked

    private void btndelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndelActionPerformed
       String num=txtNum.getText();
       try{
            pt=con.prepareStatement("insert into History values(?,?,?,?,?)");
            pt.setString(1,txtNum.getText());
            pt.setString(2,txtName.getText());
            pt.setString(3,txtStat.getText());
            pt.setString(4,txtCount.getText());
            pt.setString(5,"Delete");
            pt.executeUpdate();
          pt=con.prepareStatement("delete from ContactDetail where Number='"+num+"'");
          pt.executeUpdate();
          rs=st.executeQuery("select * from ContactDetail");
          fillgrid(rs);
          JOptionPane.showMessageDialog(this,"Delete successfully ", "Delete",1, null);
          txtNum.setVisible(false);
          txtName.setVisible(false);
          txtStat.setVisible(false);
          txtCount.setVisible(false);
          btndel.setEnabled(false);
          btnupdt.setEnabled(false);
                 
       }catch(Exception ex){
           JOptionPane.showMessageDialog(this,"Process failed ", "Failure",2, null);
       }
                
    }//GEN-LAST:event_btndelActionPerformed

    private void btnupdtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdtActionPerformed
        // TODO add your handling code here:
        String num,name,stat,cont;
        num=txtNum.getText();
        name=txtName.getText();
        stat=txtStat.getText();
        cont=txtCount.getText();
        try{
            pt=con.prepareStatement("insert into History values(?,?,?,?,?)");
            pt.setString(1,txtNum.getText());
            pt.setString(2,txtName.getText());
            pt.setString(3,txtStat.getText());
            pt.setString(4,txtCount.getText());
            pt.setString(5,"Update");
            pt.executeUpdate();
            pt=con.prepareStatement("update ContactDetail set Name=?,State=?,Country=? where Number=?");
            pt.setString(4,num);
            pt.setString(1, name);
            pt.setString(2, stat);
            pt.setString(3, cont);
            pt.executeUpdate();
           rs=st.executeQuery("select * from ContactDetail");
           fillgrid(rs);
            JOptionPane.showMessageDialog(this,"Update successfully ", "Update",1, null);
            
        }catch(Exception ex){
            JOptionPane.showMessageDialog(this,"Process failed ", "Failure",2, null);
            ex.printStackTrace();
        }
    }//GEN-LAST:event_btnupdtActionPerformed

    private void btnOKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOKActionPerformed
        int row=congrid.getRowCount();
        try{
            pt=con.prepareStatement("insert into History values(?,?,?,?,?)");
            pt.setString(1,(String)congrid.getValueAt(row-1,0));
            pt.setString(2,(String)congrid.getValueAt(row-1,1));
            pt.setString(3,(String)congrid.getValueAt(row-1,2));
            pt.setString(4,(String)congrid.getValueAt(row-1,3));
            pt.setString(5,"Search");
            pt.executeUpdate();
            
        }catch(Exception ex){}
    }//GEN-LAST:event_btnOKActionPerformed

    private void btnhisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhisActionPerformed
        new History().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnhisActionPerformed

    private void txtSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSearchKeyReleased
        String str,combo=(String)comboSearch.getSelectedItem();
       str=txtSearch.getText();
       if(combo.equals("Number")==true)
        {      
            try{
                rs=st.executeQuery("select * from ContactDetail where Number like '%"+str+"%'");
                fillgrid(rs);
                
            }catch(Exception ex){
            ex.printStackTrace();
            }
        }
       if(combo.equals("Name")==true)
        {
            try{
                rs=st.executeQuery("select * from ContactDetail where Name like '%"+str+"%'");
                fillgrid(rs);
                
            }catch(Exception ex){
            ex.printStackTrace();
            }
        }
       if(combo.equals("State")==true)
        {
            try{
                rs=st.executeQuery("select * from ContactDetail where State like '%"+str+"%'");
                fillgrid(rs);
                
            }catch(Exception ex){
            ex.printStackTrace();
            }
        }
       if(combo.equals("Country")==true)
        {
            try{
                rs=st.executeQuery("select * from ContactDetail where Country like '%"+str+"%'");
                fillgrid(rs);
                
            }catch(Exception ex){
            ex.printStackTrace();
            }
        }
        
    }//GEN-LAST:event_txtSearchKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnNew;
    private javax.swing.JButton btnOK;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btndel;
    private javax.swing.JButton btnhis;
    private javax.swing.JButton btnsetting;
    private javax.swing.JButton btnupdt;
    private javax.swing.JComboBox comboSearch;
    private javax.swing.JTable congrid;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblAdminName;
    private javax.swing.JLabel lblLogout;
    private javax.swing.JTextField txtCount;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtNum;
    private javax.swing.JTextField txtSearch;
    private javax.swing.JTextField txtStat;
    // End of variables declaration//GEN-END:variables
}
