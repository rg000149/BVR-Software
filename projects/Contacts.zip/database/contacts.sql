-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 15, 2019 at 12:57 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `contacts`
--

-- --------------------------------------------------------

--
-- Table structure for table `contactdetail`
--

CREATE TABLE `contactdetail` (
  `Number` bigint(20) NOT NULL,
  `Name` text NOT NULL,
  `State` text NOT NULL,
  `Country` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contactdetail`
--

INSERT INTO `contactdetail` (`Number`, `Name`, `State`, `Country`) VALUES
(956892619, 'veerpal', 'up', 'India'),
(7830290517, 'rajeev', 'up', 'India'),
(8800066257, 'gyan', 'up', 'India'),
(8860831808, 'rajeev kumar', 'up', 'India'),
(9149260839, 'sanjeev kumar', 'up', 'India'),
(9456892619, 'rajeev kumar', 'up', 'India');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `Number` bigint(20) NOT NULL,
  `Name` text NOT NULL,
  `State` text NOT NULL,
  `Country` text NOT NULL,
  `Work` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`Number`, `Name`, `State`, `Country`, `Work`) VALUES
(91, 'rajeev kumar', 'up', 'India', 'New Entry'),
(918, 'rajeev kumar', 'up', 'India', 'Update'),
(7830290517, 'rajeev kumar', 'up', 'India', 'New Entry'),
(8860831808, 'rajeev kumar', 'up', 'India', 'New Entry'),
(9149260839, 'sanjeev kumar', 'up', 'India', 'New Entry'),
(9193046600, 'rajeev kumar', 'up', 'India', 'Update'),
(9456892619, 'rajeev kumar', 'up', 'India', 'New Entry'),
(91, 'rajeev', 'up', 'India', 'Update'),
(914926, 'rajeev', 'up', 'India', 'Update'),
(91, 'rajeev', 'up', 'India', 'Delete'),
(7830290517, 'rajeev', 'up', 'India', 'Update'),
(8800066257, 'gyan', 'up', 'India', 'New Entry'),
(956892619, 'veerpal', 'up', 'India', 'New Entry'),
(1234567890, 'veerpal', 'up', 'India', 'New Entry'),
(1234567890, 'veerpal', 'up', 'India', 'Delete'),
(9149260839, 'sanjeev kumar', 'up', 'India', 'Search');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `Username` varchar(255) NOT NULL,
  `Password` text NOT NULL,
  `Status` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Username`, `Password`, `Status`) VALUES
('deep', '12345', 'Yes'),
('gyan', '12345', NULL),
('rajeev', '12345', NULL),
('sanjeev kumar', '12345', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contactdetail`
--
ALTER TABLE `contactdetail`
  ADD PRIMARY KEY (`Number`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD KEY `Number` (`Number`),
  ADD KEY `Number_2` (`Number`),
  ADD KEY `Number_3` (`Number`),
  ADD KEY `Number_4` (`Number`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`Username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contactdetail`
--
ALTER TABLE `contactdetail`
  MODIFY `Number` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2147483647;
--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `Number` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2147483647;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
